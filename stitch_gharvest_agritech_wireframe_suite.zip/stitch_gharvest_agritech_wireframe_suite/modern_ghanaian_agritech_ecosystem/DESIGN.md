---
name: Modern Ghanaian Agritech Ecosystem
colors:
  surface: '#eefdf4'
  surface-dim: '#ceded5'
  surface-bright: '#eefdf4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#e8f7ef'
  surface-container: '#e2f1e9'
  surface-container-high: '#dcece3'
  surface-container-highest: '#d7e6de'
  on-surface: '#111e19'
  on-surface-variant: '#414944'
  inverse-surface: '#26332e'
  inverse-on-surface: '#e5f4ec'
  outline: '#717974'
  outline-variant: '#c0c8c3'
  surface-tint: '#396756'
  primary: '#00261b'
  on-primary: '#ffffff'
  primary-container: '#0b3d2e'
  on-primary-container: '#79a894'
  inverse-primary: '#a0d1bc'
  secondary: '#146b4f'
  on-secondary: '#ffffff'
  secondary-container: '#a3f3cf'
  on-secondary-container: '#1d7155'
  tertiary: '#2b1f00'
  on-tertiary: '#ffffff'
  tertiary-container: '#453300'
  on-tertiary-container: '#c4981c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bcedd7'
  primary-fixed-dim: '#a0d1bc'
  on-primary-fixed: '#002116'
  on-primary-fixed-variant: '#214f3f'
  secondary-fixed: '#a3f3cf'
  secondary-fixed-dim: '#87d6b4'
  on-secondary-fixed: '#002115'
  on-secondary-fixed-variant: '#00513a'
  tertiary-fixed: '#ffdf98'
  tertiary-fixed-dim: '#f0c044'
  on-tertiary-fixed: '#251a00'
  on-tertiary-fixed-variant: '#5a4300'
  background: '#eefdf4'
  on-background: '#111e19'
  surface-variant: '#d7e6de'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 3.5rem
    fontWeight: '800'
    lineHeight: 4rem
    letterSpacing: -0.03em
  headline-xl:
    fontFamily: Manrope
    fontSize: 2.5rem
    fontWeight: '700'
    lineHeight: 3rem
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Manrope
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Manrope
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 1.5rem
    fontWeight: '700'
    lineHeight: 2rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Manrope
    fontSize: 1.375rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Manrope
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: '0'
  body-lg:
    fontFamily: DM Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: '0'
  body-md:
    fontFamily: DM Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: '0'
  body-sm:
    fontFamily: DM Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-lg:
    fontFamily: DM Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.02em
  label-md:
    fontFamily: DM Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.04em
  label-sm:
    fontFamily: DM Sans
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 2rem
  margin-sm: 1rem
  margin-lg: 4rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system conveys institutional trust, technological clarity, and agricultural vitality across Ghana’s farming corridors. It connects disparate market participants—from smallholder cocoa and grain aggregators in Sunyani and Tamale to cold-chain haulers and multi-national agro-processors in Tema—into a unified, transparent supply infrastructure.

The aesthetic fuses **Corporate / Modern utilitarianism** with **tactile editorial precision**:
- **Dignified & Pragmatic:** Avoids patronizing agricultural motifs. Surfaces are structured, enterprise-grade, and engineered for high-visibility under direct equatorial sunlight.
- **Traceability-First:** Design elements emphasize ledger permanence, route tracking, moisture and quality grades, and verified warehouse receipt data.
- **Regional Resonance:** Rooted in the rich soil and sun of the Guinea savannah and southern forest belt without leaning on folkloric clichés; expressed through balanced forest tones, warm parchment backdrops, and harvest metallics.

## Colors

The palette establishes an authoritative tone with deep canopy greens, harvest golds, and warm field cream.

### Roles & Semantic Mapping
- **Primary (`#0b3d2e`)**: Deep Forest Canopy. Anchor for top-level navigation, structural headers, active states, and high-impact commitments.
- **Secondary (`#126a4e`)**: Forest Accent. Used for actionable controls, interactive waypoints, logistics map paths, and progress completion states.
- **Tertiary (`#d4a72c` / `#f3ca61`)**: Harvest Gold & Sunlight Gold. Signifies certified quality, escrow releases, active grain grades, and critical alerts.
- **Neutral Dark (`#14211c`)**: Deep Ink. Replaces pure black to ensure crisp readability for high-density tabular data, weighbridge receipts, and contracts.
- **Neutral Muted (`#4a5b53`)**: Muted Sage. Reserved for metadata, helper labels, column dividers, and secondary system icons.
- **Surface Canvas (`#f7f6ef`)**: Field Cream. Ground plane that reduces screen glare in outdoor, field-station use.
- **Surface Card (`#ffffff`)**: Crisp White. Card containers, slide-over sheets, and modal viewports.

## Typography

Typography balances technical rigor with approachability.
- **Headings (Manrope):** Geometric and direct. Used for operational balances, metric readouts, crop volume statistics, and page architecture. Numeric data within headings utilizes tabular figures (`tnum`) for metric vertical alignment.
- **Body & Metadata (DM Sans):** Modern and humanized with open apertures, maintaining high legibility on lower-tier mobile displays and hand-held barcode/inventory scanners.
- **Monospace Accent:** For Batch IDs, Waybill hashes, and GPS location coordinates, use standard system monospace at `0.8125rem` with uppercase styling to ensure zero transcription errors.

## Layout & Spacing

The layout utilizes a structured fluid grid optimized for high-density logistics dashboards, mobile field data input, and procurement portals:
- **Mobile (< 768px):** 4 columns, `margin-sm` (1rem / 16px), `gutter-sm` (1rem / 16px). Bottom sheets replace side drawers; metrics stack vertically into single-column cards.
- **Tablet (768px - 1024px):** 8 columns, `margin` (2rem / 32px), `gutter` (1.5rem / 24px). Split master-detail views for warehouse manifest verification.
- **Desktop (> 1024px):** 12 columns, max-width container at `1440px`, `margin-lg` (4rem / 64px), `gutter-lg` (2rem / 32px). Allows persistent multi-filter toolbars and split route/ledger panels.
- **Rhythm:** Strictly enforced 8pt spatial cadence. Spacing tokens (`space-xs` through `space-xl`) govern all stack gaps, form layouts, and nested component padding.

## Elevation & Depth

Visual hierarchy uses crisp boundaries paired with targeted illumination rather than deep, murky dropshadows:
- **Base Canvas:** Field Cream (`#f7f6ef`) creates a natural warm substrate.
- **Level 1 (Cards, Ledger Tables):** Crisp White (`#ffffff`) background bounded by a 1px border of Muted Sage at 20% opacity (`rgba(74, 91, 83, 0.2)`). No shadow in rest state.
- **Level 2 (Hovered Cards, Dropdowns, Segment Pickers):** 1px border of Forest Accent at 30% opacity, paired with an ambient shadow: `0 4px 16px -2px rgba(11, 61, 46, 0.08)`.
- **Level 3 (Modals, Dispatch Sheets, Floating Trays):** 1px border of Forest Canopy (`#0b3d2e`) at 15% opacity, paired with dual-layer depth: `0 12px 32px -4px rgba(20, 33, 28, 0.12), 0 2px 6px 0 rgba(20, 33, 28, 0.04)`.
- **Traceability Highlight (Active Batch Nodes):** Subtle directional glow using Harvest Gold: `0 0 12px 2px rgba(212, 167, 44, 0.25)`.

## Shapes

The interface implements a refined **`roundedness: 2`** system:
- **Micro Elements (Chips, Step Points, Badges):** 0.25rem (4px) to 0.5rem (8px), maintaining structured clarity in tight tables.
- **Standard Controls (Inputs, Buttons, Dropdowns):** 0.5rem (8px) for balanced, accessible touch and click targets.
- **Structural Containers (Cards, Modals, Summary Panels):** 1rem (16px) outer corners, with nested elements scaled down to 0.5rem to preserve visual geometry.
- **Logistics Indicators & Avatars:** Circular (`50%` / pill-shaped) strictly for status lights, verified check pills, and operator profiles.

## Components

### Buttons
- **Primary Action:** Solid Deep Forest (`#0b3d2e`) background, Crisp White text, 0.5rem radius, font `label-lg`. Padding: `0.75rem 1.5rem`. Hover: Forest Accent (`#126a4e`). Active: Pressed inset feel with no layout shift.
- **Secondary Action:** Transparent background, 1.5px border of Forest Accent (`#126a4e`), Deep Forest text. Hover: Background tints with Forest Accent at 6% opacity.
- **Escrow / Financial Trigger:** Solid Harvest Gold (`#d4a72c`), Deep Ink (`#14211c`) text, font `label-lg` with `fontWeight: 700`. Hover: `#f3ca61`.

### Traceability Chips & Status Badges
- **Batch Origin Chips:** Muted Sage at 12% tint background, Deep Ink text, 1px border of Muted Sage at 25%. Monospaced tracking ID prefix (e.g., `GH-ASH-892`).
- **Glow Status Badges:** Compact pill format. 
  - *In Transit:* Forest Accent tint (`rgba(18, 106, 78, 0.1)`), Forest Accent text, pulsing 6px circular dot (`#126a4e`).
  - *Quality Certified:* Harvest Gold tint (`rgba(212, 167, 44, 0.15)`), Harvest Gold border (`#d4a72c`), Deep Ink text with a soft golden outer ring shadow.
  - *Flagged / Moisture Risk:* Muted rust background, high-contrast dark text, sharp alerting ring.

### Cards & Data Panels
- **Structure:** Crisp White surface, 1rem corner radius, padded with `space-lg` (1.5rem). 
- **Card Headers:** Manrope `headline-sm` in Deep Ink paired with right-aligned contextual status or timestamp chips.
- **Dividers:** 1px hairline horizontal stroke of Field Cream darkened to 10% or Muted Sage at 15%.

### Form Inputs & Selectors
- **Input Fields:** Crisp White background, 1px border of Muted Sage at 40%, 0.5rem corner radius, text in Deep Ink. Focus state creates a 2px outer outline in Forest Accent (`#126a4e`) with zero offset.
- **Affixes & Units:** Trailing badges for weights (`kg`, `MT`), moisture content (`%`), and currency (`GHS`) styled in Muted Sage background with Deep Ink text.

### Interactive Step Indicators (Chain of Custody)
- **Waypoints:** Horizontal multi-segment track on desktop; vertical stepper on mobile.
- **Completed Node:** Filled circle in Forest Accent (`#126a4e`) with a white check icon, connecting rail rendered in solid Forest Accent 2px line.
- **Active Node (Current Checkpoint):** Deep Forest border with Harvest Gold center dot and glowing halo (`rgba(212, 167, 44, 0.3)`).
- **Pending Node:** Muted Sage at 30% dashed line, unfilled circle with Muted Sage border.

### Selection Controls (Checkboxes & Radios)
- **Checkboxes:** 0.25rem rounded square with 1.5px Forest Canopy border. When checked, transitions to Deep Forest fill with white checkmark.
- **Radios:** Concentric circle with Deep Forest active ring and 4px inset dot.